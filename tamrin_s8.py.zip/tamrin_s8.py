# Function / Recursion / *args / **kwargs Exercises




# 1) شمارش تعداد حروف رشته

def count_chars(text):
    pass

# مثال:
# count_chars("hello") -> 5


# 2) برعکس کردن رشته

def reverse_text(text):
    pass

# مثال:
# reverse_text("python") -> "nohtyp"


# ---------------- RECURSION ----------------


# 6) فاکتوریل

def factorial(n):
    pass

# مثال:
# factorial(5) -> 120


# 7) توان عدد

def power(a, n):
    pass

# مثال:
# power(2, 5) -> 32


# 8) جمع اعداد 1 تا n

def sum_to_n(n):
    pass

# مثال:
# sum_to_n(5) -> 15


# 9) فیبوناچی

def fib(n):
    pass

# مثال:
# fib(6) -> 8


# 10) جمع عناصر لیست با recursion

def recursive_sum(nums):
    pass

# مثال:
# recursive_sum([1,2,3,4]) -> 10


# 11) palindrome با recursion

def is_palindrome(text):
    pass

# مثال:
# is_palindrome("level") -> True


# 12) countdown recursive

def countdown(n):
    pass

# مثال:
# countdown(5)
#
# 5
# 4
# 3
# 2
# 1
# Done


# ---------------- *args ----------------


# 13) جمع همه ورودی‌ها

def total(*args):
    pass

# مثال:
# total(1,2,3,4) -> 10


# 14) پیدا کردن بزرگ‌ترین مقدار

def find_max(*args):
    pass

# مثال:
# find_max(4,7,2) -> 7


# 15) میانگین اعداد

def average(*args):
    pass

# مثال:
# average(2,4,6) -> 4


# 16) چاپ همه آرگومان‌ها

def print_all(*args):
    pass

# مثال:
# print_all(1, "hello", True)


# ---------------- **kwargs ----------------


# 17) چاپ key و value

def show_info(**kwargs):
    pass

# مثال:
# show_info(name="Ali", age=20)


# 18) شمارش تعداد keyها

def count_keys(**kwargs):
    pass

# مثال:
# count_keys(a=1, b=2, c=3) -> 3


# 19) ساخت پروفایل کاربر

def create_user(**kwargs):
    pass

# مثال:
# create_user(name="Sara", city="Tehran")


# ---------------- ترکیبی ----------------


# 20) استفاده همزمان از args و kwargs

def demo(*args, **kwargs):
    pass

# مثال:
# demo(1,2,3,name="Ali", age=25)


# 21) mini print function

def my_print(*args, sep="-"):
    pass

# مثال:
# my_print(1,2,3)
#
# خروجی:
# 1-2-3


# 22) ماشین حساب

def add(a, b):
    pass

def subtract(a, b):
    pass

def multiply(a, b):
    pass

def divide(a, b):
    pass


# 23) Recursive minimum

def recursive_min(nums):
    pass

# مثال:
# recursive_min([4,1,8,2]) -> 1


# 24) logger function

def log(**kwargs):
    pass

# مثال:
# log(level="INFO", message="server started")


# 25) recursive power بدون استفاده از **

def power(a, n):
    pass

# مثال:
# power(2,10) -> 1024